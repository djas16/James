import java.util.ArrayList;

public class Kitchen {

    private ArrayList<electricobjects> Appliances;

    public Kitchen() {
        this.Appliances = new ArrayList<>();
        this.addAppliance(new kettle("Red", "Duck", 100));
        this.addAppliance(new toaster("Blue","Grey"));
    }


    public void addAppliance(electricobjects appliance) {
        this.Appliances.add(appliance);
    }
    public void turnOnAll() {
        this.Appliances.forEach(appliance -> {
            appliance.plugIn();
            appliance.isSwitchedOn();
        });
        System.out.println("Turned on all appliances");
    }



}