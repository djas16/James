
public class Student { //Class Student Created//
	String name; //Includes a String called Name
	int age; //includes an integer for age allowing us to later on allow or deny service based on the students age
	boolean isvegetation; // True or False 
	
public Student(String n, int a, boolean v) { // Constructor Expects 3  pieces of Information // 
		this.name = n; // uses name 
		this.age = a; // uses age 
		this.isvegetation = v; //uses is the person a vegetation?
		
	}

public Student(int a, boolean v) { //Constructor//
	this.name = "James"; //name set to James
	this.age = 40; //James is 40 years old
	this.isvegetation = false; //James is not a vegitation. 
}

public int getOlder() { //public void then name of behavior// //Void means it does not send back any information.// // Make Student Older//
	return age++;  // Add 1 on age //
}

public String changeName (String nn) { //changeName
	this.name = nn; //this name is the new name the user entered
	return name; // display new name.
	// System.out.println("Name Has Been Changed"); // After Return this code becomes unreacable//
	
}
@Override //override the old name with the new name.//
public String toString() { 
	return name;
}
}

