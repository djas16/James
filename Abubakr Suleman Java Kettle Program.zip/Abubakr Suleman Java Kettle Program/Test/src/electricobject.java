public abstract class electricobject {
	private boolean pluggedin;
	private boolean switchedon;
	
public electricobject() {
	pluggedin = false;
    switchedon = false;
    }

public void plugin() {
	pluggedin = true;
}

public boolean isswitchedOn() {
	return switchedon;
}


public void unplug() {
	pluggedin = false;
}

public void pressSwitch() {
	if(pluggedin) {
		switchedon = !switchedon;
		System.out.println(switchedon ? "Switched on" : "Switched off");
	} else {
		System.out.println("The Kettle is not plugged in");
	}
	 
	
	
}
}

