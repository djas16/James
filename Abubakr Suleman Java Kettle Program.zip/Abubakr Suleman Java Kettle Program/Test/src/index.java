public class index {
	public static void main(String[]args) {
		System.out.println("test");
		kettle abubakr = new kettle ("Chrome","Samsung",500); // This Kettle is the colour Chrome, is made by Samsung & is 500ml filled.
		System.out.println(abubakr); // This prints out the Value of the Kettle Abubakr with the Color,Company and how many liters is in it
		abubakr.fillUp(100); // This code is used to add 100ml 
		System.out.println(abubakr); // outputs the information with the 100ml added. increase the value of ml by 100 as integer
		abubakr.pour(50); // pours out 50ml, reduces the value of ml filled by 50ml as integer
		System.out.println(abubakr); // outputs the value of water inside the kettle after 100ml been added and 50ml is poured out
		abubakr.pour(150); // pours out 150ml from the kettle, decreases the value by 150ml as an integer 
		System.out.println(abubakr); // outputs the changes aswell as the volume of water being decreased by 150ml 
		abubakr.pour(150); // pours out 150ml from the kettle, decreases the value by 150ml as an integer
		System.out.println(abubakr); // outputs the changes aswell as the volume of water being decreased by 150ml 
		abubakr.fillUp(100); // pours out 100ml from the kettle, decreases the value by 150ml as an integer
		System.out.println(abubakr); // outputs the changes aswell as the volume of water being decreased by 100ml 
		abubakr.fillUp(100); // pours out 100ml from the kettle, decreases the value by 150ml as an integer
		System.out.println(abubakr); // outputs the changes aswell as the volume of water being decreased by 100ml
		abubakr.fillUp(100);// pours out 100ml from the kettle, decreases the value by 150ml as an integer
		System.out.println(abubakr); // outputs the changes aswell as the volume of water being decreased by 100ml
		abubakr.fillUp(1000000); // pours out 1000000ml from the kettle, decreases the value by 150ml as an integer
		System.out.println(abubakr); //outputs Too much Water,Overflow. Alongside outputting 500ml/500ml meaning the kettle is full.
		
		
	}
}
