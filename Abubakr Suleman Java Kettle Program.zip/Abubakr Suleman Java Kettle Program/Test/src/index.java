public class index {
	public static void main(String[]args) {
		Student james = new Student(17,false);
		
	}
}

