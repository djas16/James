public class kettle {
	
	String color;
	String manufacturer; 
	int maxCapacity;
	int currentCapacity;
	
	public kettle(String c, String m, int mc) {
		System.out.println("I have Created a New Kettle");
		this.color = c;
		this.manufacturer = m;
		this.maxCapacity = mc;
		this.currentCapacity = 0;
		}
	public void fillUp(int amount) {
		if (this.currentCapacity + amount > this.maxCapacity) {
			this.currentCapacity = this.maxCapacity;
			System.out.println("Too much Water,Overflow");
		} else {
			this.currentCapacity += amount;
		}
	}
	public String toString() {
		return color + " " + manufacturer + " " + currentCapacity+"/"+ maxCapacity;
	}
	
	public void pour(int amount) {
		if (currentCapacity>=50) {
			currentCapacity -= 50;
		} else {
			System.out.println("Not Enough Water for a cup of Tea"); 
		}
		
	}
}
