public class kettle extends electricobject {
	
	private String color;
	private String manufacturer; 
	private String description;
	private int maxCapacity;
	private int currentCapacity;
	

	public kettle(String c, String m, int mc) {
		System.out.println("I have Created a New Kettle");
		this.color = c;
		this.manufacturer = m;
		this.maxCapacity = mc;
		this.currentCapacity = 0;
		}
	public void fillUp(int amount) {
		if (this.currentCapacity + amount > this.maxCapacity) {
			this.currentCapacity = this.maxCapacity;
			System.out.println("Too much Water,Overflow");
		} else {
			this.currentCapacity += amount;
		}
	}
	
	public String toString() {
		return color + " " + manufacturer + " " + currentCapacity+"/"+ maxCapacity;
	}
	
	public void pour() {
		if (currentCapacity>=50) {
			currentCapacity -= 50;
		} else {
			System.out.println("Not Enough Water for a cup of Tea"); 
		}
	}

	@Override
	public void pressSwitch() {
		super.pressSwitch();
		if (this.isswitchedOn() && this.currentCapacity > 0) {
			this.description = "boiling";
			super.pressSwitch();
		}
		
	}
		
}
