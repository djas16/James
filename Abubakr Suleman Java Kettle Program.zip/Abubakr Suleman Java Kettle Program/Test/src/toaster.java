import java.io.File;

import javafx.application.Application;
import javafx.embed.swing.JFXPanel;
import javafx.scene.*;
import javafx.scene.media.*;

public class Toaster extends ElectricObject {
    
    private String colour;
    private String manufacturer;
    private int toast;
    private int maxToast;
    private boolean isToasted;
    final JFXPanel fxPanel;

    public Toaster(String colour, String manufacturer, int maxToast) {
        this.colour = colour;
        this.manufacturer = manufacturer;
        this.toast = 0;
        this.maxToast = maxToast;
        this.isToasted = false;
        this.fxPanel = new JFXPanel();
    }
    
    public void toastIt() {
        // From parent class ElectricObject, returns if the kettle is on
        if (this.isSwitchedOn() && this.toast == 0) {
            System.out.println("Toasting...");
            
            try {
                Thread.sleep(5000);
                isToasted = true; // Sets boiled to true
                System.out.println("pinggggggggggg!"); // Prints when boiled
                String musicFile = "src/Toaster.mp3";     // For example
                Media sound = new Media(new File(musicFile).toURI().toString());
                MediaPlayer mediaPlayer = new MediaPlayer(sound);
                mediaPlayer.play();
                
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } 
    } 
} 