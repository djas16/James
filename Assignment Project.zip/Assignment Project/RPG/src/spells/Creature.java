package spells;

public interface Creature {}
