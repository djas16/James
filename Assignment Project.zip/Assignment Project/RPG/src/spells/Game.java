package spells;

public class Game {

}
