package spells;

import java.awt.event.ActionListener;

import javax.swing.JLabel;

public class Healing extends Spell implements Creature {

	public Healing() {
		super("Healing");
	}

	@Override
	public ActionListener getEventListener(Player player, JLabel mana) {
		// TODO Auto-generated method stub
		return null;
	}


}
