package spells;

public interface TargetsCreature {

}
