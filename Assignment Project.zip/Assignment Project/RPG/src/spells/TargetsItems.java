package spells;

public interface TargetsItems {

}
