package spells;

public interface TargetsLocation {

}
